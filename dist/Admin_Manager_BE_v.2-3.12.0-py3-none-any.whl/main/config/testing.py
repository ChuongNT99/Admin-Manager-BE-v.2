class TestingConfig:
    DEBUG = False
    TESTING = False
    SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://root:001122@localhost/booking'
    SECRET_KEY = 'ea07b6f188aefe221dbe0d076210910d281365fa218bc935472431734d8c07b8'
