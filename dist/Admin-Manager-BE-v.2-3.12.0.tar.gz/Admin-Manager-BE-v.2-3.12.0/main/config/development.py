class DevelopmentConfig:
    DEBUG = True
    TESTING = False
    SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://root:001122@localhost/booking'
    SECRET_KEY = '4fe0b47d792564142aeebd6d71b58533df73b6ef09497142bc14f8b51b275286'
